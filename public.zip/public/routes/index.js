var express = require('express');
var router = express.Router();
var app = express();

app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

router.get('/', function(request, response){
    response.send("Welcome to the course app!")
 });

 app.get('/*',function(request, response){
    response.send("App wildcard GET route");
 });

 module.exports = router;