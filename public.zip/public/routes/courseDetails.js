var express = require('express');
var router = express.Router();
var app = express();

app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

app.get('/course', function (req, res) {
   res.render('details');
 })

 app.get('/', function (req, res) {
   res.render('details');
 })

router.get('/coursedetails', function (req, res) {
      var courseModel = require('./../models/Course');
      console.log(req.query);
      console.log(Object.keys(courseModel));
      res.render('courseView', {course:courseModel});
});


router.get('/*',function(req,res){
   res.send('app default route');
});
    
module.exports = router;