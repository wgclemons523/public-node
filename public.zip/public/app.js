var express = require('express');
var app = express();
var course = require('./models/Course.js');

app.set('view engine', 'ejs');

app.use('/assets', express.static('assets'));

app.use('/course',course);

app.get('/', function(request, response){
   response.render("details")
});


app.listen(8084, function(){
   console.log('app started')
   console.log('listening on port 8084')
});