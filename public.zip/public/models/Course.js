var course = function(id, ti, te, ins){
 var courseModel = {
  courseID: id,
  courseTitle: ti,
  courseTerm: te,
  courseInstructor: ins
};
return courseModel;
};
module.exports.course = course;

